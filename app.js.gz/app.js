
//  background-image: url(bg-kidazuf.webp);

var body = document.getElementsByTagName('body')[0];
//body.style.backgroundImage = 'url(bg-drit_opt.webp)';


